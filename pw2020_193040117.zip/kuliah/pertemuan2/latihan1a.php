<?php
	$a ="bakso";
	$b ="bulat";

	echo $a." itu ".$b.",".$b." itu ".$a;
?>