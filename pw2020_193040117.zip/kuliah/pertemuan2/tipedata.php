<?php
 	//pembuatan variabel
 	$nama_variabel ="value";	
	// data pribadi
	//$nama = "lukman tresnahadi"; //string
	//$umur = "20";

	//echo $nama;
	//echo "<br>";
	//echo $umur."tahun";

 ?>