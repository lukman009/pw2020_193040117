<?php
	$a = 15 ;
	
	echo "aku adalah angka" .$a;
	echo "<br>";
	echo "jika aku di kali 5 maka,aku sekarang bernilai". ($a*=5);
	echo "<br>";
	echo "jika aku di bagi 3 maka, aku sekarang bernilai".($a/=3);
	echo "<br>";
	echo "jika aku di kurang 30 maka,aku sekarang bernilai".($a-=30);
	echo "<br>";
	echo "jika aku di tambah 10 maka,aku sekarang bernilai" .($a+=10);

?>