<?php 
	//array asociative
$mahasiswa = array("nama" => "wahyu",
	"nrp" =>"193040000",
	"alamat" => "karawang",
	"usia" => "19 tahun");
	echo $mahasiswa ["nama"];
	echo "<hr>";

	//array biasa
	$mahasiswa = array("wahyu","193040000",
		"karawang","19 tahun");
	echo $mahasiswa[0];
		

 ?>