<?php 
	$mahasiswa =[
		"001" =>"Ahmad",
		"002" =>"budi",
		"003" =>"Chika"
	];
	foreach ($mahasiswa as $nrp => $nama){
		echo "$nrp : $nama <br>";
	}
 ?>