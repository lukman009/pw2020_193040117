<?php 
	//array assosisatif
	$lukman = array (
				"nama" => "lukman",
				"ttl" => "Tasikmalaya,21 november 2000",
				"alamat" => "193040117",
				"status" => "mahasiswa",
				"no hp" => "087818860563",
				"cita-cita" => "berguna bagi bangsa",
				"hobi" => "olahraga",
				"makanan fav" =>"cuanki",
				"instagram" => "lukmantrsnhdi",
				"email" =>"tresnahadi3@gmail.com",
				"lagufav" =>"popies lane memory");
	echo "<br>";

	foreach ($lukman as $a => $datadiri) {
		echo "$a : $datadiri <br>";
		# code...
	}



 ?>