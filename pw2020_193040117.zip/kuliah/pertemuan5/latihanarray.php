<?php 
	$bulan = array("Januari","februari","maret","april","mei","Juni","juli","agustus","september","oktober","november","desember");
	for ($i=0; $i <count($bulan) ; $i++) { 
		echo "bulan= ".$bulan[$i];
		echo "<br>";                                                                                      
	}
	
 ?>