<?php 	
	//	for ($i=0; $i <9 ; $i++){
	//echo "Nilai ".  $i."<br>";

		//}

		$i = 0;
		while ($i <= 10) {
			echo "<li>Urutan ke-$i</li>" .$i."<br>";
			$i++;
		}
 ?>