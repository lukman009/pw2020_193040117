<?php 
		$nilai = 10 ;
		$hasil = ($nilai%2 == 0)? "genap":"ganjil";
		echo "$hasil";

		if (($nilai%2) ==1){
			echo "ganjil";
		}else{
			echo "genap";
		}
	// $nilai = 51 ;
	// if (($nilai%2) == 1){
	//echo "ganjil";
	// }else{
	//echo " genap" ;
	//}

	//$warna_lampu ="hijau";
	//if ($warna_lampu == "merah"){
		//echo "berhenti";
	//}elseif ($warna_lampu == "kuning") {
		//echo "bersiap";
	//}elseif (strtoupper($warna_lampu == "hijau") {
		//echo "maju";
	//}else{
		//echo "warna tidak dikenal";

		//$hari = 0.99;

		//if ($hari <=1){
			//echo "hari minggu | dari if";
		//}elseif ($hari == 2){
			//echo "hari senin |dari if";
		
 ?>