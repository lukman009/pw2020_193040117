<!DOCTYPE html>
<html>
<head>
	<title>Latihan</title>
</head>
<body>
	<form method="get" action="hasillatihan.php">
		<table>
			<tr>
			<td>nilai 1</td>
			<td><input type="text" name="nilai1"></td>
		</tr>
			<tr>
				<td>nilai 2 </td>
				<td><input type="text" name="nilai2"></td>
			</tr>
			<tr>
				<td></td>
				<td><button type="submit">Hasil</button></td>
			</tr>

		</table>

</body>
</html>