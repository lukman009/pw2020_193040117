<!DOCTYPE html>
<html>
<head>
	<title>FORM</title>
</head>
<body>
	<form method="get" action="hasil.php">
		<table>
			<tr>
				<td>username</td>
				<td><input type="text" name="username"></td>
			</tr>
			<tr>
				<td>password</td>
				<td><input type="password" name="password"></td>
			</tr>
			<tr>
				<td></td>
				<td><button type="submit">login</button></td>
			</tr>
	</form>

</body>
</html>